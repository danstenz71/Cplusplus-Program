
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddAndDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Jane", "Doe", "0987654321", "456 Main St");
        service.addContact(contact);
        assertEquals(1, service.getContacts().size());
        service.deleteContact("123");
        assertEquals(0, service.getContacts().size());
    }

    @Test
    public void testUpdateContactFields() {
        ContactService service = new ContactService();
        Contact contact = new Contact("124", "Alex", "Smith", "1111111111", "789 Main St");
        service.addContact(contact);
        service.updateFirstName("124", "Sam");
        service.updateLastName("124", "Johnson");
        service.updatePhone("124", "2222222222");
        service.updateAddress("124", "987 Main St");
        assertEquals("Sam", service.getContacts().get(0).getFirstName());
        assertEquals("Johnson", service.getContacts().get(0).getLastName());
        assertEquals("2222222222", service.getContacts().get(0).getPhone());
        assertEquals("987 Main St", service.getContacts().get(0).getAddress());
    }

    @Test
    public void testDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("125", "Anna", "Lee", "3333333333", "123 Main St");
        Contact contact2 = new Contact("125", "Bill", "Ray", "4444444444", "456 Main St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }
}
